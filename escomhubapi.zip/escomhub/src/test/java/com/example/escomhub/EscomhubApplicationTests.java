package com.example.escomhub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EscomhubApplicationTests {

	@Test
	void contextLoads() {
	}

}
