package com.example.escomhub.controller;

import com.example.escomhub.security.JwtTokenUtil;
import com.example.escomhub.service.RefreshTokenService;
import com.example.escomhub.model.Usuario;
import com.example.escomhub.model.Vendedor;
import com.example.escomhub.repository.UsuarioRepository;
import com.example.escomhub.repository.VendedorRepository;
import com.example.escomhub.dto.LoginRequestDTO;
import com.example.escomhub.dto.RegisterRequestDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private VendedorRepository vendedorRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private RefreshTokenService refreshTokenService;

    // Endpoint de login para usuarios normales
    @PostMapping("/login/user")
    public ResponseEntity<String> loginUser(@RequestBody LoginRequestDTO loginRequest) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));

        String token = jwtTokenUtil.generateAccessToken(authentication.getName());
        return ResponseEntity.ok(token);
    }

    // Endpoint de login para vendedores
    @PostMapping("/login/vendedor")
    public ResponseEntity<String> loginVendedor(@RequestBody LoginRequestDTO loginRequest) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));

        String token = jwtTokenUtil.generateAccessToken(authentication.getName());
        return ResponseEntity.ok(token);
    }

    // Endpoint de registro para usuarios normales
    @PostMapping("/register/user")
    public ResponseEntity<String> registerUser(@RequestBody RegisterRequestDTO registerRequest) {
        if (usuarioRepository.findByUsername(registerRequest.getUsername()).isPresent()) {
            return ResponseEntity.status(400).body("El nombre de usuario ya existe.");
        }
        Usuario nuevoUsuario = new Usuario();
        nuevoUsuario.setUsername(registerRequest.getUsername());
        nuevoUsuario.setContrasenaHash(passwordEncoder.encode(registerRequest.getPassword()));
        usuarioRepository.save(nuevoUsuario);
        return ResponseEntity.status(201).body("Usuario registrado con éxito.");
    }

    // Endpoint de registro para vendedores
    @PostMapping("/register/vendedor")
    public ResponseEntity<String> registerVendedor(@RequestBody RegisterRequestDTO registerRequest) {
        if (vendedorRepository.findByUsername(registerRequest.getUsername()).isPresent()) {
            return ResponseEntity.status(400).body("El nombre de usuario ya existe.");
        }
        Vendedor nuevoVendedor = new Vendedor();
        nuevoVendedor.setUsername(registerRequest.getUsername());
        nuevoVendedor.setContrasenaHash(passwordEncoder.encode(registerRequest.getPassword()));
        vendedorRepository.save(nuevoVendedor);
        return ResponseEntity.status(201).body("Vendedor registrado con éxito.");
    }

    // Endpoint para refresh token
    @PostMapping("/refresh-token")
    public ResponseEntity<String> refreshToken(@RequestBody String refreshToken) {
        if (refreshTokenService.validateRefreshToken(refreshToken)) {
            String username = jwtTokenUtil.getUsernameFromToken(refreshToken);
            String newAccessToken = jwtTokenUtil.generateAccessToken(username);
            return ResponseEntity.ok("Bearer " + newAccessToken);
        } else {
            return ResponseEntity.status(401).body("Refresh Token no válido");
        }
    }
}
