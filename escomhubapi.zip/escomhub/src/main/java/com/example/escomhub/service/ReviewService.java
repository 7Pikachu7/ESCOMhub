package com.example.escomhub.service;

import com.example.escomhub.model.Producto;
import com.example.escomhub.model.Review;
import com.example.escomhub.repository.ProductoRepository;
import com.example.escomhub.repository.ReviewRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReviewService {

    private final ProductoRepository productoRepository;

    @Autowired
    private ReviewRepository reviewRepository;

    ReviewService(ProductoRepository productoRepository) {
        this.productoRepository = productoRepository;
    }

    // Crear una nueva reseña
    @PreAuthorize("hasRole('USER')")
    public Review createReview(Long productoId, Review review) {
        // Buscamos el producto por su ID
        Producto producto = productoRepository.findById(productoId)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado"));

        // Asignamos el producto a la reseña
        review.setProducto(producto);

        return reviewRepository.save(review);
    }

    // Obtener todas las reseñas de un producto
    @PreAuthorize("permitAll()")
    public List<Review> getReviewsByProductoId(Long productoId) {
        return reviewRepository.findByProductoId(productoId);
    }

    // Obtener todas las reseñas de un usuario
    @PreAuthorize("#usuarioId == principal.id")
    public List<Review> getReviewsByUsuarioId(Long usuarioId) {
        return reviewRepository.findByUsuarioId(usuarioId);
    }
}
