package com.example.escomhub.service;

import com.example.escomhub.model.Vendedor;
import com.example.escomhub.repository.VendedorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class VendedorService {

    @Autowired
    private VendedorRepository vendedorRepository;

    // Obtener todos los vendedores
    @PreAuthorize("permitAll()")
    public List<Vendedor> getAllVendedores() {
        return vendedorRepository.findAll(); // Retorna todos los vendedores de la base de datos
    }

    // Obtener un vendedor por su ID
    @PreAuthorize("#id == principal.id")
    public Vendedor getVendedorById(Long id) {
        Optional<Vendedor> vendedor = vendedorRepository.findById(id);
        return vendedor.orElse(null); // Devuelve el vendedor o null si no se encuentra
    }

    // Crear un nuevo vendedor
    @PreAuthorize("permitAll()")
    public Vendedor createVendedor(Vendedor vendedor) {
        return vendedorRepository.save(vendedor); // Guarda el nuevo vendedor en la base de datos
    }

    // Actualizar un vendedor existente
    @PreAuthorize("#id == principal.id")
    public Vendedor updateVendedor(Long id, Vendedor vendedor) {
        if (vendedorRepository.existsById(id)) {
            vendedor.setId(id); // Establece el ID del vendedor para actualizar
            return vendedorRepository.save(vendedor); // Guarda la actualización en la base de datos
        }
        return null; // Si no existe, retorna null
    }

    // Eliminar un vendedor por ID
    @PreAuthorize("#id == principal.id")
    public void deleteVendedor(Long id) {
        if (vendedorRepository.existsById(id)) {
            vendedorRepository.deleteById(id); // Elimina el vendedor de la base de datos
        }
    }
}
