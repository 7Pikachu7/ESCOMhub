package com.example.escomhub.dto;

import java.util.List;

public class CarritoDTO {

    private Long id;
    private Long usuarioId;
    private List<CarritoItemDTO> items; // Representa los elementos en el carrito

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(Long usuarioId) {
        this.usuarioId = usuarioId;
    }

    public List<CarritoItemDTO> getItems() {
        return items;
    }

    public void setItems(List<CarritoItemDTO> items) {
        this.items = items;
    }
}
