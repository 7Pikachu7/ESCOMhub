package com.example.escomhub.controller;

import com.example.escomhub.model.Producto;
import com.example.escomhub.service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.time.LocalDate;

@RestController
@RequestMapping("/productos")
public class ProductoController {

    @Autowired
    private ProductoService productoService;

    // Obtener todos los productos
    @GetMapping
    public ResponseEntity<List<Producto>> getAllProductos() {
        List<Producto> productos = productoService.getAllProductos();
        return ResponseEntity.ok(productos);
    }

    // Obtener producto por ID
    @GetMapping("/{id}")
    public ResponseEntity<Producto> getProductoById(@PathVariable Long id) {
        Producto producto = productoService.getProductoById(id);
        return producto != null ? ResponseEntity.ok(producto) : ResponseEntity.notFound().build();
    }

    // Crear un nuevo producto (solo para vendedores)
    @PreAuthorize("hasRole('VENDEDOR')")
    @PostMapping
    public ResponseEntity<Producto> createProducto(@RequestBody Producto producto) {
        Producto nuevoProducto = productoService.createProducto(producto);
        return ResponseEntity.status(201).body(nuevoProducto);
    }

    // Actualizar producto (solo para vendedores)
    @PreAuthorize("hasRole('VENDEDOR')")
    @PutMapping("/{id}")
    public ResponseEntity<Producto> updateProducto(@PathVariable Long id, @RequestBody Producto producto) {
        Producto actualizado = productoService.updateProducto(id, producto);
        return actualizado != null ? ResponseEntity.ok(actualizado) : ResponseEntity.notFound().build();
    }

    // Eliminar producto (solo para vendedores)
    @PreAuthorize("hasRole('VENDEDOR')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProducto(@PathVariable Long id) {
        productoService.deleteProducto(id);
        return ResponseEntity.noContent().build();
    }

    // Buscar productos por nombre (búsqueda parcial)
    @GetMapping("/nombre")
    public ResponseEntity<List<Producto>> getProductosByNombre(@RequestParam String nombre) {
        List<Producto> productos = productoService.buscarProductosPorNombre(nombre);
        return ResponseEntity.ok(productos);
    }

    // Buscar productos por vendedor
    @GetMapping("/vendedor/{vendedorId}")
    public ResponseEntity<List<Producto>> getProductosByVendedor(@PathVariable Long vendedorId) {
        List<Producto> productos = productoService.buscarProductosPorVendedor(vendedorId);
        return ResponseEntity.ok(productos);
    }

    // Buscar productos por descripción (búsqueda parcial)
    @GetMapping("/descripcion")
    public ResponseEntity<List<Producto>> getProductosByDescripcion(@RequestParam String descripcion) {
        List<Producto> productos = productoService.buscarProductosPorDescripcion(descripcion);
        return ResponseEntity.ok(productos);
    }

    // Buscar productos por precio (menor o igual a un valor)
    @GetMapping("/precio")
    public ResponseEntity<List<Producto>> getProductosByPrecio(@RequestParam Double precio) {
        List<Producto> productos = productoService.buscarProductosPorPrecio(precio);
        return ResponseEntity.ok(productos);
    }

    // Buscar productos por fecha de publicación
    @GetMapping("/fecha-publicacion")
    public ResponseEntity<List<Producto>> getProductosByFechaPublicacion(@RequestParam String fecha) {
        List<Producto> productos = productoService.buscarProductosPorFechaPublicacion(LocalDate.parse(fecha));
        return ResponseEntity.ok(productos);
    }
}
