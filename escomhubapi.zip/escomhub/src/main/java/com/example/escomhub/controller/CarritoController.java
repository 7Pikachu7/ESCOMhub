package com.example.escomhub.controller;

import com.example.escomhub.model.Carrito;
import com.example.escomhub.model.CarritoItem;
import com.example.escomhub.service.CarritoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.access.prepost.PreAuthorize;

@RestController
@RequestMapping("/carrito")
@PreAuthorize("hasRole('USER')")
public class CarritoController {

    @Autowired
    private CarritoService carritoService;

    @GetMapping("/{usuarioId}")
    public ResponseEntity<Carrito> getCarritoByUsuario(@PathVariable Long usuarioId) {
        Carrito c = carritoService.getCarritoByUsuario(usuarioId);
        return c != null ? ResponseEntity.ok(c) : ResponseEntity.notFound().build();
    }

    @PostMapping("/{usuarioId}/items")
    public ResponseEntity<CarritoItem> addProductoToCarrito(@PathVariable Long usuarioId,
            @RequestBody CarritoItem carritoItem) {
        return ResponseEntity.status(201).body(carritoService.addProductoToCarrito(usuarioId, carritoItem));
    }

    @DeleteMapping("/{usuarioId}/items/{itemId}")
    public ResponseEntity<Void> removeProductoFromCarrito(@PathVariable Long usuarioId,
            @PathVariable Long itemId) {
        carritoService.removeProductoFromCarrito(usuarioId, itemId);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{usuarioId}")
    public ResponseEntity<Void> emptyCarrito(@PathVariable Long usuarioId) {
        carritoService.emptyCarrito(usuarioId);
        return ResponseEntity.noContent().build();
    }
}
