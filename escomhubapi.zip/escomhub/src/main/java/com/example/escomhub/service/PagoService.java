package com.example.escomhub.service;

import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.PaymentIntent;
import com.stripe.net.RequestOptions;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class PagoService {

    @Value("${stripe.api.key}") // Asegúrate de que la clave de la API esté en tu archivo application.properties
    private String stripeApiKey;

    // Método para crear un PaymentIntent en Stripe (procesar un pago)
    // Método para crear un PaymentIntent en Stripe (procesar un pago)
    public PaymentIntent createPaymentIntent(Double amount) throws StripeException {
        // Establecer la clave de la API de Stripe
        Stripe.apiKey = stripeApiKey;

        // Crear los parámetros del PaymentIntent
        Map<String, Object> paymentIntentParams = new HashMap<>();
        paymentIntentParams.put("amount", (int) (amount * 100)); // El monto en pesos
        paymentIntentParams.put("currency", "mxn"); // Usamos MXN para pesos mexicanos

        // Creando un PaymentIntent con Stripe
        return PaymentIntent.create(paymentIntentParams);
    }

    // Método para obtener el estado de un PaymentIntent
    public PaymentIntent getPaymentIntent(String paymentIntentId) throws StripeException {
        return PaymentIntent.retrieve(paymentIntentId);
    }

    // Método para confirmar el pago de un PaymentIntent
    public PaymentIntent confirmPaymentIntent(String paymentIntentId) throws StripeException {
        PaymentIntent paymentIntent = PaymentIntent.retrieve(paymentIntentId);
        return paymentIntent.confirm(); // Confirmar el pago
    }

    // Método para cancelar el pago de un PaymentIntent
    public PaymentIntent cancelPaymentIntent(String paymentIntentId) throws StripeException {
        PaymentIntent paymentIntent = PaymentIntent.retrieve(paymentIntentId);
        return paymentIntent.cancel(); // Cancelar el pago
    }
}
