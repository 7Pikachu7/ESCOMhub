package com.example.escomhub.repository;

import com.example.escomhub.model.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface TicketRepository extends JpaRepository<Ticket, Long> {

    // Método de consulta por la relación "orden" en Ticket
    Optional<Ticket> findByOrdenId(Long ordenId);
}
