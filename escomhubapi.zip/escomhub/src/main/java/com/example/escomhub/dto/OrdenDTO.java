package com.example.escomhub.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

public class OrdenDTO {

    @NotNull(message = "El total de la orden no puede ser nulo")
    private Double total;

    @NotEmpty(message = "El método de pago es obligatorio")
    private String metodoPago;

    @NotEmpty(message = "La dirección de envío no puede estar vacía")
    private String direccionEnvio;

    private String comentariosAdicionales;

    // Getters y Setters
    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }

    public String getDireccionEnvio() {
        return direccionEnvio;
    }

    public void setDireccionEnvio(String direccionEnvio) {
        this.direccionEnvio = direccionEnvio;
    }

    public String getComentariosAdicionales() {
        return comentariosAdicionales;
    }

    public void setComentariosAdicionales(String comentariosAdicionales) {
        this.comentariosAdicionales = comentariosAdicionales;
    }
}
