package com.example.escomhub.service;

import com.example.escomhub.model.Usuario;
import com.example.escomhub.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    // Obtener un usuario por ID
    @PreAuthorize("#id == principal.id")
    public Usuario getUsuarioById(Long id) {
        return usuarioRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado con ID: " + id));
    }

    // Crear un nuevo usuario
    @PreAuthorize("permitAll()")
    public Usuario createUsuario(Usuario usuario) {
        // Verificar si el usuario ya existe
        if (usuarioRepository.existsByUsername(usuario.getUsername())) {
            throw new IllegalArgumentException("El nombre de usuario ya está en uso.");
        }

        // Cifrar la contraseña antes de guardar
        usuario.setContrasenaHash(passwordEncoder.encode(usuario.getContrasenaHash()));
        return usuarioRepository.save(usuario);
    }

    // Buscar usuario por nombre de usuario
    @PreAuthorize("#id == principal.id")
    public Optional<Usuario> getUsuarioByUsername(String username) {
        return usuarioRepository.findByUsername(username);
    }

    // Buscar usuario por email
    @PreAuthorize("#id == principal.id")
    public Optional<Usuario> getUsuarioByEmail(String correoElectronico) {
        return usuarioRepository.findByCorreoElectronico(correoElectronico);
    }

    // Actualizar los detalles del usuario
    @PreAuthorize("#id == principal.id")
    public Usuario updateUsuario(Long id, Usuario usuario) {
        if (usuarioRepository.existsById(id)) {
            usuario.setId(id); // Mantener el ID actual del usuario
            return usuarioRepository.save(usuario);
        } else {
            throw new IllegalArgumentException("Usuario no encontrado con ID: " + id);
        }
    }

    // Eliminar un usuario
    @PreAuthorize("#id == principal.id")
    public void deleteUsuario(Long id) {
        if (!usuarioRepository.existsById(id)) {
            throw new IllegalArgumentException("Usuario no encontrado con ID: " + id);
        }
        usuarioRepository.deleteById(id);
    }
}
