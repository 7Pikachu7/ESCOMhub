package com.example.escomhub.repository;

import com.example.escomhub.model.Vendedor;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface VendedorRepository extends JpaRepository<Vendedor, Long> {
    Optional<Vendedor> findByUsername(String username);
}
