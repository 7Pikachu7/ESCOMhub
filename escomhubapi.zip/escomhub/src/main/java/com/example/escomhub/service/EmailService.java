package com.example.escomhub.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import java.io.ByteArrayInputStream;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender javaMailSender;

    // Método para enviar un correo electrónico con un archivo adjunto
    // Método para enviar un correo electrónico con un archivo adjunto
    public void sendEmailWithAttachment(String to, String subject, String body, byte[] attachment, String fileName)
            throws MessagingException {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);

        helper.setTo(to);
        helper.setSubject(subject);
        helper.setText(body);
        helper.addAttachment(fileName, () -> new ByteArrayInputStream(attachment));

        javaMailSender.send(mimeMessage); // Enviar el correo electrónico
    }

}
