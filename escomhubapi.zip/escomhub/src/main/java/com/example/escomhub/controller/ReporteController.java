package com.example.escomhub.controller;

import com.example.escomhub.service.ReporteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.access.prepost.PreAuthorize;

import java.util.Map;

@RestController
@RequestMapping("/reportes")
public class ReporteController {

    @Autowired
    private ReporteService reporteService;

    @PreAuthorize("hasRole('VENDEDOR')")
    @GetMapping("/ventas/dia")
    public ResponseEntity<Map<String, Double>> getVentasPorDia() {
        return ResponseEntity.ok(reporteService.getVentasPorDia());
    }

    @PreAuthorize("hasRole('VENDEDOR')")
    @GetMapping("/ventas/producto")
    public ResponseEntity<Map<String, Double>> getVentasPorProducto() {
        return ResponseEntity.ok(reporteService.getVentasPorProducto());
    }
}
