package com.example.escomhub.service;

import com.example.escomhub.model.Usuario;
import com.example.escomhub.repository.UsuarioRepository;
import com.example.escomhub.security.JwtTokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    // Registrar un nuevo usuario
    public Usuario registerUser(Usuario usuario) {
        if (usuarioRepository.findByUsername(usuario.getUsername()).isPresent()) {
            throw new RuntimeException("El nombre de usuario ya está registrado");
        }
        usuario.setContrasenaHash(passwordEncoder.encode(usuario.getContrasenaHash())); // Cifrar la contraseña
        return usuarioRepository.save(usuario);
    }

    // Iniciar sesión (autenticación) y generar el token JWT
    public String loginUser(String username, String password) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(username, password));

        // Generar el token JWT (Se usa generateAccessToken en lugar de generateToken)
        User user = (User) authentication.getPrincipal();
        return jwtTokenUtil.generateAccessToken(user.getUsername()); // Cambiado de generateToken a generateAccessToken
    }
}
