package com.example.escomhub.controller;

import com.example.escomhub.service.TicketService;
import jakarta.mail.MessagingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.access.prepost.PreAuthorize;

@RestController
@RequestMapping("/tickets")
public class TicketController {

    @Autowired
    private TicketService ticketService;

    @PreAuthorize("hasRole('USER')")
    @PostMapping("/{ordenId}")
    public ResponseEntity<String> generateTicket(@PathVariable Long ordenId, @RequestParam String email) {
        try {
            ticketService.generateAndSendTicket(ordenId, email);
            return ResponseEntity.ok("Ticket enviado correctamente.");
        } catch (MessagingException e) {
            return ResponseEntity.status(500).body("Error al enviar el correo: " + e.getMessage());
        } catch (RuntimeException e) {
            return ResponseEntity.status(400).body("Error: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error desconocido: " + e.getMessage());
        }
    }

    @PreAuthorize("hasRole('USER')")
    @PostMapping("/reenvio/{ordenId}")
    public ResponseEntity<String> resendTicket(@PathVariable Long ordenId) {
        try {
            ticketService.resendTicket(ordenId);
            return ResponseEntity.ok("Ticket reenviado correctamente.");
        } catch (RuntimeException e) {
            return ResponseEntity.status(400).body("Error: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error desconocido: " + e.getMessage());
        }
    }
}
