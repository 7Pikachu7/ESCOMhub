package com.example.escomhub.service;

import com.example.escomhub.model.Producto;
import com.example.escomhub.repository.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
//import java.util.Optional;

@Service
public class ProductoService {

    @Autowired
    private ProductoRepository productoRepository;

    // Obtener todos los productos
    @PreAuthorize("permitAll()")
    public List<Producto> getAllProductos() {
        return productoRepository.findAll();
    }

    // Obtener un producto por ID
    @PreAuthorize("permitAll()")
    public Producto getProductoById(Long id) {
        return productoRepository.findById(id).orElse(null);
    }

    // Crear un nuevo producto
    @PreAuthorize("hasRole('VENDEDOR')")
    public Producto createProducto(Producto producto) {
        return productoRepository.save(producto);
    }

    // Actualizar un producto
    @PreAuthorize("hasRole('VENDEDOR') and #id == principal.id")
    public Producto updateProducto(Long id, Producto producto) {
        if (productoRepository.existsById(id)) {
            producto.setId(id); // Establecer el ID del producto para que se actualice en la base de datos
            return productoRepository.save(producto);
        }
        return null;
    }

    // Eliminar un producto
    @PreAuthorize("hasRole('VENDEDOR') and #id == principal.id")
    public void deleteProducto(Long id) {
        productoRepository.deleteById(id);
    }

    // Buscar productos por nombre
    @PreAuthorize("permitAll()")
    public List<Producto> buscarProductosPorNombre(String nombre) {
        return productoRepository.findByNombreContaining(nombre); // Búsqueda parcial por nombre
    }

    // Buscar productos por vendedor
    @PreAuthorize("permitAll()")
    public List<Producto> buscarProductosPorVendedor(Long vendedorId) {
        return productoRepository.findByVendedorId(vendedorId);
    }

    // Buscar productos por descripción
    @PreAuthorize("permitAll()")
    public List<Producto> buscarProductosPorDescripcion(String descripcion) {
        return productoRepository.findByDescripcionContaining(descripcion); // Búsqueda parcial por descripción
    }

    // Buscar productos por precio (menor o igual a un valor)
    @PreAuthorize("permitAll()")
    public List<Producto> buscarProductosPorPrecio(Double precio) {
        return productoRepository.findByPrecioUnitarioLessThanEqual(precio);
    }

    // Buscar productos por fecha de publicación (productos publicados antes de una
    // fecha)
    @PreAuthorize("permitAll()")
    public List<Producto> buscarProductosPorFechaPublicacion(LocalDate fecha) {
        return productoRepository.findByFechaPublicacionBefore(fecha);
    }
}
