package com.example.escomhub.repository;

import com.example.escomhub.model.OrdenItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrdenItemRepository extends JpaRepository<OrdenItem, Long> {
}
