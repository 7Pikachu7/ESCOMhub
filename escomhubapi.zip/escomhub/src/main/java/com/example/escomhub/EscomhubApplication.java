package com.example.escomhub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EscomhubApplication {

	public static void main(String[] args) {
		SpringApplication.run(EscomhubApplication.class, args);
	}

}
