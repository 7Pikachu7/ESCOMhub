package com.example.escomhub.repository;

import com.example.escomhub.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.time.LocalDate;
import java.util.Optional;

public interface ProductoRepository extends JpaRepository<Producto, Long> {

    // Buscar producto por ID
    Optional<Producto> findById(Long id); // Devuelve un Optional<Producto> para manejar el caso en que no se encuentre
                                          // el producto

    // Buscar productos por nombre (búsqueda parcial)
    List<Producto> findByNombreContaining(String nombre); // Productos cuyo nombre contiene una cadena de texto

    // Buscar productos por ID de vendedor
    List<Producto> findByVendedorId(Long vendedorId); // Productos de un vendedor específico

    // Buscar productos por descripción (búsqueda parcial)
    List<Producto> findByDescripcionContaining(String descripcion); // Productos cuya descripción contiene una cadena

    // Buscar productos por precio (precio menor o igual a un valor)
    List<Producto> findByPrecioUnitarioLessThanEqual(Double precio); // Productos cuyo precio es menor o igual a un
                                                                     // valor específico

    // Buscar productos por fecha de publicación (productos publicados antes de una
    // fecha)
    List<Producto> findByFechaPublicacionBefore(LocalDate fecha); // Productos publicados antes de una fecha determinada

    // Buscar productos por categoría (usando la relación ManyToOne con la entidad
    // Categoria)
    List<Producto> findByCategoriaId(Long categoriaId); // Productos de una categoría específica

    // Buscar productos por existencias (productos con existencias mayores a un
    // valor)
    List<Producto> findByExistenciasGreaterThan(Integer existencias); // Productos con existencias mayores a un valor
                                                                      // específico

    // Buscar productos por unidades vendidas (productos que tienen más o menos
    // unidades vendidas)
    List<Producto> findByUnidadesVendidasGreaterThan(Integer unidadesVendidas); // Productos con más unidades vendidas
                                                                                // que un valor específico

    // Buscar productos por nombre y categoría (búsqueda filtrada por nombre y
    // categoría)
    List<Producto> findByNombreContainingAndCategoriaId(String nombre, Long categoriaId); // Productos cuyo nombre
                                                                                          // contiene una cadena y
                                                                                          // pertenecen a una categoría

    // Buscar productos por precio y unidades vendidas (productos cuyo precio es
    // menor o igual a un valor y unidades vendidas mayor a un valor)
    List<Producto> findByPrecioUnitarioLessThanEqualAndUnidadesVendidasGreaterThan(Double precio,
            Integer unidadesVendidas); // Productos cuyo precio es menor o igual a un valor y unidades vendidas mayor a
                                       // un valor

    // Buscar productos por vendedor, categoría y estado de existencias
    List<Producto> findByVendedorIdAndCategoriaIdAndExistenciasGreaterThan(Long vendedorId, Long categoriaId,
            Integer existencias); // Productos de un vendedor y categoría específicos, con existencias mayores a
                                  // un valor
}
