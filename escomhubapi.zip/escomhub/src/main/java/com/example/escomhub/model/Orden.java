package com.example.escomhub.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
public class Orden {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "usuario_id", nullable = false)
    private Usuario usuario;

    @OneToMany(mappedBy = "orden")
    private List<OrdenItem> ordenItems;

    @Column(nullable = false)
    private Double total;

    @Column(nullable = false)
    private String metodoPago;

    private String direccionEnvio;

    private String comentariosAdicionales;

    @Column(nullable = false)
    private String estadoTicket; // "pendiente", "enviado", etc.

    @Column(nullable = false)
    private String estadoPago; // "pendiente", "completado", etc.

    private String detallesPago; // Agregado para almacenar detalles del pago, como número de transacción

    @Column(nullable = false)
    private LocalDateTime fecha; // Agregar la fecha de emisión

    // Getters y Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public List<OrdenItem> getOrdenItems() {
        return ordenItems;
    }

    public void setOrdenItems(List<OrdenItem> ordenItems) {
        this.ordenItems = ordenItems;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }

    public String getDireccionEnvio() {
        return direccionEnvio;
    }

    public void setDireccionEnvio(String direccionEnvio) {
        this.direccionEnvio = direccionEnvio;
    }

    public String getComentariosAdicionales() {
        return comentariosAdicionales;
    }

    public void setComentariosAdicionales(String comentariosAdicionales) {
        this.comentariosAdicionales = comentariosAdicionales;
    }

    public String getEstadoTicket() {
        return estadoTicket;
    }

    public void setEstadoTicket(String estadoTicket) {
        this.estadoTicket = estadoTicket;
    }

    public String getEstadoPago() {
        return estadoPago;
    }

    public void setEstadoPago(String estadoPago) {
        this.estadoPago = estadoPago;
    }

    public String getDetallesPago() {
        return detallesPago;
    }

    public void setDetallesPago(String detallesPago) {
        this.detallesPago = detallesPago;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }
}
