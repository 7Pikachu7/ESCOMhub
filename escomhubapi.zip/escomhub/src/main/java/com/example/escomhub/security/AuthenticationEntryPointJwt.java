package com.example.escomhub.security;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import jakarta.servlet.http.HttpServletRequest; // Correcta importación para HttpServletRequest
import jakarta.servlet.http.HttpServletResponse; // Correcta importación para HttpServletResponse
import java.io.IOException;

@Component
public class AuthenticationEntryPointJwt implements AuthenticationEntryPoint {

    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response,
            AuthenticationException authException)
            throws IOException {

        // Enviar respuesta con código de error 401 (No autorizado) y un mensaje
        response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Error: No autorizado!"); // Mensaje de error si no hay
                                                                                          // un token válido
    }
}
