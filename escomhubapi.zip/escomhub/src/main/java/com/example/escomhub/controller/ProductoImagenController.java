package com.example.escomhub.controller;

import com.example.escomhub.service.ProductoImagenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.security.access.prepost.PreAuthorize;

import java.io.IOException;

@RestController
@RequestMapping("/productos/{productoId}/imagen")
public class ProductoImagenController {

    @Autowired
    private ProductoImagenService productoImagenService;

    @PreAuthorize("hasRole('VENDEDOR')")
    @PostMapping
    public ResponseEntity<String> uploadImage(@PathVariable Long productoId, @RequestParam MultipartFile file)
            throws IOException {
        String url = productoImagenService.uploadImage(productoId, file);
        return ResponseEntity.status(201).body("Imagen subida: " + url);
    }

    @PreAuthorize("permitAll()")
    @GetMapping
    public ResponseEntity<byte[]> getImage(@PathVariable Long productoId) throws IOException {
        byte[] data = productoImagenService.getImage(productoId);
        return ResponseEntity.ok(data);
    }
}
