package com.example.escomhub.service;

import com.example.escomhub.model.RefreshToken;
import com.example.escomhub.model.Usuario;
import com.example.escomhub.repository.RefreshTokenRepository;
import com.example.escomhub.repository.UsuarioRepository;
import com.example.escomhub.security.JwtTokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RefreshTokenService {

    @Autowired
    private RefreshTokenRepository refreshTokenRepository;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private UsuarioRepository usuarioRepository;

    // Validar el refresh token
    public boolean validateRefreshToken(String refreshToken) {
        String username = jwtTokenUtil.getUsernameFromToken(refreshToken);
        RefreshToken token = refreshTokenRepository.findByTokenAndUsuarioUsername(refreshToken, username)
                .orElseThrow(() -> new RuntimeException("Token de refresco no válido"));

        return jwtTokenUtil.validateToken(token.getToken());
    }

    // Generar un nuevo refresh token
    public String generateRefreshToken(String username) {
        return jwtTokenUtil.generateRefreshToken(username);
    }

    // Obtener el usuario asociado con el refresh token
    public Usuario getUserFromRefreshToken(String refreshToken) {
        String username = jwtTokenUtil.getUsernameFromToken(refreshToken);
        return usuarioRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
    }
}
