package com.example.escomhub.repository;

import com.example.escomhub.model.Orden;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.time.LocalDate;
import java.util.List;

public interface OrdenRepository extends JpaRepository<Orden, Long> {

    // Buscar todas las órdenes de un usuario
    List<Orden> findByUsuarioId(Long usuarioId);

    // Consulta personalizada para obtener ventas por día
    @Query("SELECT FUNCTION('DATE', o.fecha), SUM(o.total) FROM Orden o GROUP BY FUNCTION('DATE', o.fecha)")
    List<Object[]> findVentasPorDia();

    // Consulta personalizada para obtener ventas por producto
    @Query("SELECT oi.producto.nombre, SUM(oi.cantidad * oi.precioUnitario) " +
            "FROM Orden o " +
            "JOIN o.ordenItems oi " +
            "GROUP BY oi.producto")
    List<Object[]> findVentasPorProducto(); // Devuelve un listado de productos y el total de ventas de cada uno
}
