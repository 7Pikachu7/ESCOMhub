package com.example.escomhub.repository;

import com.example.escomhub.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    Optional<Usuario> findByUsername(String username); // Método para encontrar un usuario por su nombre de usuario

    Optional<Usuario> findByCorreoElectronico(String correoElectronico); // Método para encontrar un usuario por su
                                                                         // correo electrónico

    // Método para verificar si ya existe un usuario con el mismo nombre de usuario
    boolean existsByUsername(String username);
}
