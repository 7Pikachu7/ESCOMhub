package com.example.escomhub.repository;

import com.example.escomhub.model.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ReviewRepository extends JpaRepository<Review, Long> {
    List<Review> findByProductoId(Long productoId); // Buscar reseñas por producto

    List<Review> findByUsuarioId(Long usuarioId); // Buscar reseñas por usuario
}
