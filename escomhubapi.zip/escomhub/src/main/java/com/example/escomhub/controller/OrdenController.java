package com.example.escomhub.controller;

import com.example.escomhub.model.Orden;
import com.example.escomhub.service.OrdenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.access.prepost.PreAuthorize;

import java.util.List;

@RestController
@RequestMapping("/ordenes")
public class OrdenController {

    @Autowired
    private OrdenService ordenService;

    @PreAuthorize("hasRole('USER')")
    @PostMapping
    public ResponseEntity<Orden> createOrden(@RequestBody Orden orden) {
        return ResponseEntity.status(201).body(ordenService.createOrden(orden));
    }

    @PreAuthorize("hasRole('USER')")
    @GetMapping("/{usuarioId}")
    public ResponseEntity<List<Orden>> getOrdenesByUsuario(@PathVariable Long usuarioId) {
        return ResponseEntity.ok(ordenService.getOrdenesByUsuario(usuarioId));
    }

    @PreAuthorize("hasRole('USER')")
    @GetMapping("/detalle/{id}")
    public ResponseEntity<Orden> getOrdenById(@PathVariable Long id) {
        Orden o = ordenService.getOrdenById(id);
        return o != null ? ResponseEntity.ok(o) : ResponseEntity.notFound().build();
    }

    @PreAuthorize("hasRole('USER')")
    @PutMapping("/{id}")
    public ResponseEntity<Orden> updateOrden(@PathVariable Long id, @RequestBody Orden orden) {
        Orden updated = ordenService.updateOrden(id, orden);
        return updated != null ? ResponseEntity.ok(updated) : ResponseEntity.notFound().build();
    }
}
