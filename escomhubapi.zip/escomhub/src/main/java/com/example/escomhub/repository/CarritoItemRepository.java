package com.example.escomhub.repository;

import com.example.escomhub.model.CarritoItem;
import com.example.escomhub.model.Carrito;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CarritoItemRepository extends JpaRepository<CarritoItem, Long> {

    // Eliminar todos los items de un carrito específico
    void deleteAllByCarrito(Carrito carrito);
}
