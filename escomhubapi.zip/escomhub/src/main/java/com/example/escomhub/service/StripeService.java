package com.example.escomhub.service;

import com.stripe.exception.StripeException;
import com.stripe.model.PaymentIntent;
import com.stripe.net.RequestOptions;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class StripeService {

    // Método para crear un PaymentIntent en Stripe
    public PaymentIntent createPaymentIntent(Double amount) throws StripeException {
        Map<String, Object> paymentIntentParams = new HashMap<>();
        paymentIntentParams.put("amount", (int) (amount * 100)); // El monto en centavos
        paymentIntentParams.put("currency", "usd");

        return PaymentIntent.create(paymentIntentParams); // Llama a Stripe para crear el pago
    }
}
