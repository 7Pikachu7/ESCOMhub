package com.example.escomhub.dto;

import java.util.List;

public class OrderResponseDTO {

    private Long id;
    private Long usuarioId;
    private Double total;
    private String metodoPago;
    private String estadoPago;
    private String estadoTicket;
    private String direccionEnvio;
    private List<OrdenItemDTO> ordenItems;

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(Long usuarioId) {
        this.usuarioId = usuarioId;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }

    public String getEstadoPago() {
        return estadoPago;
    }

    public void setEstadoPago(String estadoPago) {
        this.estadoPago = estadoPago;
    }

    public String getEstadoTicket() {
        return estadoTicket;
    }

    public void setEstadoTicket(String estadoTicket) {
        this.estadoTicket = estadoTicket;
    }

    public String getDireccionEnvio() {
        return direccionEnvio;
    }

    public void setDireccionEnvio(String direccionEnvio) {
        this.direccionEnvio = direccionEnvio;
    }

    public List<OrdenItemDTO> getOrdenItems() {
        return ordenItems;
    }

    public void setOrdenItems(List<OrdenItemDTO> ordenItems) {
        this.ordenItems = ordenItems;
    }
}
