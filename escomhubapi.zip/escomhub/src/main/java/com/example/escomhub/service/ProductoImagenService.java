package com.example.escomhub.service;

import com.example.escomhub.model.Producto;
import com.example.escomhub.repository.ProductoRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.util.StringUtils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Service
public class ProductoImagenService {

    // Directorio local donde se almacenarán las imágenes (esto puede configurarse
    // desde application.properties)
    @Value("${product.images.directory}")
    private String imagesDirectory;

    private final ProductoRepository productoRepository;

    public ProductoImagenService(ProductoRepository productoRepository) {
        this.productoRepository = productoRepository;
    }

    // Subir una imagen para un producto
    public String uploadImage(Long productoId, MultipartFile file) throws IOException {
        // Validar si el producto existe
        Producto producto = productoRepository.findById(productoId)
                .orElseThrow(() -> new IllegalArgumentException("Producto no encontrado"));

        // Asegurarse de que el archivo no esté vacío
        if (file.isEmpty()) {
            throw new IOException("No se ha subido ningún archivo.");
        }

        // Obtener el nombre del archivo
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());

        // Crear la ruta donde se almacenará la imagen
        Path uploadPath = Paths.get(imagesDirectory);
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath); // Crear el directorio si no existe
        }

        // Definir la ruta del archivo en el servidor
        Path filePath = uploadPath.resolve(fileName);

        // Guardar el archivo en el servidor
        file.transferTo(filePath.toFile());

        // Actualizar el producto con la URL o el nombre de la imagen
        producto.setImagen(fileName); // O podrías guardar la URL completa dependiendo de tu lógica
        productoRepository.save(producto);

        // Devolver la URL o nombre del archivo (si decides almacenar el nombre)
        return filePath.toUri().toString(); // Esto devuelve la URI del archivo almacenado
    }

    // Obtener la imagen del producto
    public byte[] getImage(Long productoId) throws IOException {
        Producto producto = productoRepository.findById(productoId)
                .orElseThrow(() -> new IllegalArgumentException("Producto no encontrado"));

        // Obtener el nombre del archivo de la imagen desde el producto
        String fileName = producto.getImagen();
        if (fileName == null) {
            throw new IllegalArgumentException("Este producto no tiene una imagen asociada");
        }

        // Cargar la imagen desde el directorio local
        Path filePath = Paths.get(imagesDirectory).resolve(fileName);
        return Files.readAllBytes(filePath); // Leer los bytes del archivo de imagen
    }
}
