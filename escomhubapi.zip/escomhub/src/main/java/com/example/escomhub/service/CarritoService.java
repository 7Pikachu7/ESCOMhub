package com.example.escomhub.service;

import com.example.escomhub.model.Carrito;
import com.example.escomhub.model.CarritoItem;
import com.example.escomhub.model.Usuario;
import com.example.escomhub.repository.CarritoRepository;
import com.example.escomhub.repository.CarritoItemRepository;
import com.example.escomhub.repository.UsuarioRepository; // Asegúrate de tener el repositorio de Usuario
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;

@Service
public class CarritoService {

    @Autowired
    private CarritoRepository carritoRepository;

    @Autowired
    private CarritoItemRepository carritoItemRepository;

    @Autowired
    private UsuarioRepository usuarioRepository; // Inyectamos el repositorio de Usuario

    // Obtener carrito de un usuario
    @PreAuthorize("#usuarioId == principal.id")
    public Carrito getCarritoByUsuario(Long usuarioId) {
        return carritoRepository.findByUsuarioId(usuarioId).orElse(null);
    }

    // Agregar un producto al carrito
    @PreAuthorize("#usuarioId == principal.id")
    public CarritoItem addProductoToCarrito(Long usuarioId, CarritoItem carritoItem) {
        // Buscamos el usuario por su ID
        Usuario usuario = usuarioRepository.findById(usuarioId)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        // Obtenemos el carrito del usuario
        Carrito carrito = getCarritoByUsuario(usuarioId);
        if (carrito == null) {
            carrito = new Carrito();
            carrito.setUsuario(usuario); // Aquí asignamos el objeto Usuario
            carrito = carritoRepository.save(carrito);
        }
        carritoItem.setCarrito(carrito);
        return carritoItemRepository.save(carritoItem);
    }

    // Eliminar un producto del carrito
    @PreAuthorize("#usuarioId == principal.id")
    public void removeProductoFromCarrito(Long usuarioId, Long itemId) {
        Carrito carrito = getCarritoByUsuario(usuarioId);
        if (carrito != null) {
            carritoItemRepository.deleteById(itemId);
        }
    }

    // Vaciar el carrito
    @PreAuthorize("#usuarioId == principal.id")
    public void emptyCarrito(Long usuarioId) {
        Carrito carrito = getCarritoByUsuario(usuarioId);
        if (carrito != null) {
            carritoItemRepository.deleteAllByCarrito(carrito);
        }
    }
}
