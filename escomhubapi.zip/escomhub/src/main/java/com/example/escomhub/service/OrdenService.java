package com.example.escomhub.service;

import com.example.escomhub.model.Orden;
import com.example.escomhub.repository.OrdenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrdenService {

    @Autowired
    private OrdenRepository ordenRepository;

    // Crear una nueva orden
    @PreAuthorize("hasRole('USER')")
    public Orden createOrden(Orden orden) {
        return ordenRepository.save(orden);
    }

    // Obtener todas las órdenes de un usuario
    @PreAuthorize("#usuarioId == principal.id")
    public List<Orden> getOrdenesByUsuario(Long usuarioId) {
        return ordenRepository.findByUsuarioId(usuarioId);
    }

    // Obtener una orden por ID
    @PreAuthorize("#usuarioId == principal.id")
    public Orden getOrdenById(Long id) {
        return ordenRepository.findById(id).orElse(null);
    }

    // Actualizar el estado de la orden
    @PreAuthorize("#usuarioId == principal.id")
    public Orden updateOrden(Long id, Orden orden) {
        if (ordenRepository.existsById(id)) {
            orden.setId(id);
            return ordenRepository.save(orden);
        }
        return null;
    }

    // Eliminar una orden
    @PreAuthorize("#usuarioId == principal.id")
    public void deleteOrden(Long id) {
        ordenRepository.deleteById(id);
    }
}
