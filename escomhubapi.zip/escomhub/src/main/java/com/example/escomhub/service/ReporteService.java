package com.example.escomhub.service;

import com.example.escomhub.repository.OrdenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ReporteService {

    @Autowired
    private OrdenRepository ordenRepository;

    // Método para obtener las ventas por día
    @PreAuthorize("hasRole('VENDEDOR')")
    public Map<String, Double> getVentasPorDia() {
        // Llamamos al repositorio para obtener las ventas por día
        List<Object[]> ventasPorDia = ordenRepository.findVentasPorDia();

        // Creamos un Map para almacenar las fechas y los totales de ventas
        Map<String, Double> reporteVentasPorDia = new HashMap<>();

        // Iteramos sobre los resultados y los agregamos al Map
        for (Object[] row : ventasPorDia) {
            String fecha = row[0].toString(); // Fecha del producto
            Double totalVentas = (Double) row[1]; // Total de ventas para ese día
            reporteVentasPorDia.put(fecha, totalVentas); // Agregamos al Map
        }

        return reporteVentasPorDia;
    }

    // Método para obtener las ventas por producto
    @PreAuthorize("hasRole('VENDEDOR')")
    public Map<String, Double> getVentasPorProducto() {
        // Llamamos al repositorio para obtener las ventas por producto
        List<Object[]> ventasPorProducto = ordenRepository.findVentasPorProducto();

        // Creamos un Map para almacenar los nombres de productos y los totales de
        // ventas
        Map<String, Double> reporteVentasPorProducto = new HashMap<>();

        // Iteramos sobre los resultados y los agregamos al Map
        for (Object[] row : ventasPorProducto) {
            String nombreProducto = (String) row[0]; // Nombre del producto
            Double totalVentas = (Double) row[1]; // Total de ventas para ese producto
            reporteVentasPorProducto.put(nombreProducto, totalVentas); // Agregamos al Map
        }

        return reporteVentasPorProducto;
    }
}
