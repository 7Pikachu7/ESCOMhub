package com.example.escomhub.security;

import com.example.escomhub.security.JwtAuthenticationFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;

@Configuration
@EnableMethodSecurity(prePostEnabled = true) // Habilitar la seguridad a nivel de método
public class SecurityConfig {

    private final CustomUserDetailsService userDetailsService;
    private final JwtTokenUtil jwtTokenUtil;
    private final PasswordEncoder passwordEncoder;

    public SecurityConfig(CustomUserDetailsService userDetailsService,
            JwtTokenUtil jwtTokenUtil,
            PasswordEncoder passwordEncoder) {
        this.userDetailsService = userDetailsService;
        this.jwtTokenUtil = jwtTokenUtil;
        this.passwordEncoder = passwordEncoder;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf().disable() // Deshabilitar CSRF (generalmente para aplicaciones sin sesión)
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/auth/**").permitAll() // Permitir acceso a la autenticación sin necesidad
                                                                 // de// login

                        .requestMatchers(HttpMethod.GET, "/productos/**").permitAll() // Permitir acceso a productos
                        .requestMatchers(HttpMethod.POST, "/productos/**").hasRole("VENDEDOR") // Solo vendedores pueden
                                                                                               // crear productos
                        .requestMatchers("/ordenes/**").hasRole("USER") // Solo usuarios autenticados pueden acceder a
                                                                        // ordenes
                        .anyRequest().authenticated()) // Requiere autenticación para cualquier otra ruta
                .addFilterBefore(new JwtAuthenticationFilter(jwtTokenUtil, userDetailsService),
                        UsernamePasswordAuthenticationFilter.class); // Añadir el filtro de autenticación JWT

        return http.build();
    }

    @Bean
    public AuthenticationManager authenticationManager(HttpSecurity http) throws Exception {
        AuthenticationManagerBuilder authBuilder = http.getSharedObject(AuthenticationManagerBuilder.class);
        authBuilder.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder); // Configurar la
                                                                                             // autenticación
        return authBuilder.build(); // Retornar el objeto AuthenticationManager
    }
}
