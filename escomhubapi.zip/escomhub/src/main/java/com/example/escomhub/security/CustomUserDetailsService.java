package com.example.escomhub.security;

import com.example.escomhub.model.Usuario;
import com.example.escomhub.model.Vendedor;
import com.example.escomhub.repository.UsuarioRepository;
import com.example.escomhub.repository.VendedorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

import java.util.Collections;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private VendedorRepository vendedorRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Primero intenta con los usuarios
        Usuario usuario = usuarioRepository.findByUsername(username).orElse(null);
        if (usuario != null) {
            return new CustomUserDetails(
                    usuario.getId(),
                    usuario.getUsername(),
                    usuario.getContrasenaHash(),
                    Collections.singletonList(new SimpleGrantedAuthority("ROLE_" + usuario.getRol())));
        }

        // Luego intenta con los vendedores
        Vendedor vendedor = vendedorRepository.findByUsername(username).orElse(null);
        if (vendedor != null) {
            return new CustomUserDetails(
                    vendedor.getId(),
                    vendedor.getUsername(),
                    vendedor.getContrasenaHash(),
                    Collections.singletonList(new SimpleGrantedAuthority("ROLE_" + vendedor.getRol())));
        }

        throw new UsernameNotFoundException("Usuario o vendedor no encontrado con username: " + username);
    }
}
