package com.example.escomhub.controller;

import com.example.escomhub.model.Review;
import com.example.escomhub.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.access.prepost.PreAuthorize;

import java.util.List;

@RestController
@RequestMapping("/productos/{productoId}/reviews")
public class ReviewController {

    @Autowired
    private ReviewService reviewService;

    @PreAuthorize("permitAll()")
    @GetMapping
    public ResponseEntity<List<Review>> getReviews(@PathVariable Long productoId) {
        return ResponseEntity.ok(reviewService.getReviewsByProductoId(productoId));
    }

    @PreAuthorize("hasRole('USER')")
    @PostMapping
    public ResponseEntity<Review> createReview(@PathVariable Long productoId, @RequestBody Review review) {
        return ResponseEntity.status(201).body(reviewService.createReview(productoId, review));
    }
}
