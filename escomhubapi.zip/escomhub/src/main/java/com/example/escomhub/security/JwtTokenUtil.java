package com.example.escomhub.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.security.Keys;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.security.Key;

@Component
public class JwtTokenUtil {

    @Value("${jwt.secret}")
    private String JWT_SECRET_KEY;

    @Value("${jwt.access-token-expiration-time}")
    private long ACCESS_TOKEN_EXPIRATION_TIME;

    @Value("${jwt.refresh-token-expiration-time}")
    private long REFRESH_TOKEN_EXPIRATION_TIME;

    // Generar una clave secreta (Key) a partir de la clave secreta en formato
    // String
    private Key getSigningKey() {
        return Keys.hmacShaKeyFor(JWT_SECRET_KEY.getBytes()); // Usa la clave secreta de configuración
    }

    // Generar el Access Token
    public String generateAccessToken(String username) {
        return Jwts.builder()
                .setSubject(username)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + ACCESS_TOKEN_EXPIRATION_TIME)) // Tiempo de
                                                                                                    // expiración del
                                                                                                    // Access Token
                .signWith(getSigningKey(), SignatureAlgorithm.HS512)
                .compact();
    }

    // Generar el Refresh Token
    public String generateRefreshToken(String username) {
        return Jwts.builder()
                .setSubject(username)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + REFRESH_TOKEN_EXPIRATION_TIME)) // Tiempo de
                                                                                                     // expiración del
                                                                                                     // Refresh Token
                .signWith(getSigningKey(), SignatureAlgorithm.HS512)
                .compact();
    }

    // Obtener el nombre de usuario desde el token
    public String getUsernameFromToken(String token) {
        return getClaimsFromToken(token).getSubject(); // Extrae el nombre de usuario del token
    }

    // Obtener los Claims (información) del token
    public Claims getClaimsFromToken(String token) {
        try {
            return Jwts.parser()
                    .setSigningKey(getSigningKey()) // Usa la clave secreta para verificar la firma
                    .parseClaimsJws(token)
                    .getBody();
        } catch (ExpiredJwtException e) {
            throw new RuntimeException("Token ha expirado", e);
        } catch (SignatureException e) {
            throw new RuntimeException("Firma del token no válida", e);
        } catch (MalformedJwtException e) {
            throw new RuntimeException("Token malformado", e);
        } catch (JwtException e) {
            throw new RuntimeException("No se pudo parsear el token", e);
        } catch (Exception e) {
            throw new RuntimeException("Error inesperado al procesar el token", e);
        }
    }

    // Validar un token (verifica si ha expirado)
    public boolean validateToken(String token) {
        return !getClaimsFromToken(token).getExpiration().before(new Date()); // Verifica si el token ha expirado
    }

    // Extraer el token desde la cabecera de la solicitud
    public String getTokenFromRequest(String request) {
        String prefix = "Bearer ";
        if (request != null && request.startsWith(prefix)) {
            return request.substring(prefix.length()); // Extrae el token del encabezado Authorization
        }
        return null;
    }
}
