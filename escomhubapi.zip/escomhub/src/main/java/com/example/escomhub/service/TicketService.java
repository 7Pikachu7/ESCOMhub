package com.example.escomhub.service;

import com.example.escomhub.model.Ticket;
import com.example.escomhub.model.Orden;
import com.example.escomhub.model.Usuario;
import com.example.escomhub.model.OrdenItem;
import com.example.escomhub.repository.TicketRepository;
import com.example.escomhub.repository.OrdenRepository;
import com.example.escomhub.repository.UsuarioRepository;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.UnitValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import jakarta.mail.MessagingException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
//import java.util.List;

@Service
public class TicketService {

        @Autowired
        private OrdenRepository ordenRepository;

        @Autowired
        private TicketRepository ticketRepository;

        @Autowired
        private UsuarioRepository usuarioRepository;

        @Autowired
        private EmailService emailService;

        // Generar un PDF del ticket para una orden
        // Generar un PDF del ticket para una orden
        @PreAuthorize("#ordenId == principal.id")
        public Ticket generateAndSendTicket(Long ordenId, String email) throws IOException, MessagingException {
                Orden orden = ordenRepository.findById(ordenId)
                                .orElseThrow(() -> new RuntimeException("Orden no encontrada"));

                Usuario usuario = usuarioRepository.findById(orden.getUsuario().getId())
                                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

                // Crear PDF más detallado
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                PdfWriter writer = new PdfWriter(baos);
                PdfDocument pdf = new PdfDocument(writer);
                Document document = new Document(pdf);

                // Encabezado del ticket
                document.add(new Paragraph("ESCOM HUB - TICKET DE COMPRA")
                                .setFontSize(18)
                                .setBold());

                document.add(new Paragraph("\n"));

                // Información del cliente
                document.add(new Paragraph("INFORMACIÓN DEL CLIENTE").setBold());
                document.add(new Paragraph("Nombre: " + usuario.getNombre() + " " +
                                usuario.getApellidoPaterno() + " " + usuario.getApellidoMaterno()));
                document.add(new Paragraph("Boleta: " + usuario.getNumeroBoleta()));
                document.add(new Paragraph("Email: " + usuario.getCorreoElectronico()));
                document.add(new Paragraph("\n"));

                // Información de la orden
                document.add(new Paragraph("INFORMACIÓN DE LA ORDEN").setBold());
                document.add(new Paragraph("ID de Orden: " + orden.getId()));
                document.add(
                                new Paragraph("Fecha: " + orden.getFecha()
                                                .format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))));
                document.add(new Paragraph("Estado: " + orden.getEstadoTicket()));
                document.add(new Paragraph("Método de Pago: " + orden.getMetodoPago()));

                if (orden.getDireccionEnvio() != null) {
                        document.add(new Paragraph("Dirección de Envío: " + orden.getDireccionEnvio()));
                }
                document.add(new Paragraph("\n"));

                // Tabla de productos (si tienes la relación configurada)
                if (orden.getOrdenItems() != null && !orden.getOrdenItems().isEmpty()) {
                        document.add(new Paragraph("PRODUCTOS COMPRADOS").setBold());

                        Table table = new Table(UnitValue.createPercentArray(new float[] { 3, 1, 2, 2 }));
                        table.setWidth(UnitValue.createPercentValue(100));

                        // Headers
                        table.addHeaderCell("Producto");
                        table.addHeaderCell("Cantidad");
                        table.addHeaderCell("Precio Unit.");
                        table.addHeaderCell("Subtotal");

                        // Datos
                        for (OrdenItem item : orden.getOrdenItems()) {
                                // Convertir precio unitario y cantidad a BigDecimal
                                BigDecimal precioUnitario = BigDecimal.valueOf(item.getPrecioUnitario());
                                BigDecimal cantidad = BigDecimal.valueOf(item.getCantidad());

                                // Calcular el subtotal multiplicando precio unitario por cantidad
                                BigDecimal subtotal = precioUnitario.multiply(cantidad);

                                // Agregar los valores a la tabla
                                table.addCell(item.getProducto().getNombre());
                                table.addCell(String.valueOf(item.getCantidad()));
                                table.addCell("$" + precioUnitario.toString());
                                table.addCell("$" + subtotal.toString());
                        }

                        document.add(table);
                        document.add(new Paragraph("\n"));
                }

                // Total
                document.add(new Paragraph("TOTAL: $" + orden.getTotal())
                                .setFontSize(14)
                                .setBold());

                document.add(new Paragraph("\n"));
                document.add(new Paragraph("¡Gracias por tu compra en ESCOM Hub!"));

                if (orden.getComentariosAdicionales() != null) {
                        document.add(new Paragraph("\nComentarios: " + orden.getComentariosAdicionales()));
                }

                document.close();

                // Guardar ticket en la base de datos
                Ticket ticket = new Ticket();
                ticket.setOrden(orden);
                ticket.setArchivoPdf(baos.toByteArray());
                ticketRepository.save(ticket);

                // Enviar por email con nombre personalizado
                String fileName = String.format("ticket-orden-%d-%s.pdf",
                                orden.getId(),
                                orden.getFecha().format(DateTimeFormatter.ofPattern("ddMMyyyy")));

                emailService.sendEmailWithAttachment(
                                email, // Use the provided email parameter here
                                "Ticket de Compra - Orden #" + orden.getId(),
                                createEmailBody(usuario, orden),
                                baos.toByteArray(),
                                fileName);

                // Actualizar estado del ticket
                orden.setEstadoTicket("enviado");
                ordenRepository.save(orden);

                return ticket;
        }

        // Reenviar ticket existente
        @PreAuthorize("#ordenId == principal.id")
        public void resendTicket(Long ordenId) throws IOException, MessagingException {
                Ticket ticket = ticketRepository.findByOrdenId(ordenId)
                                .orElseThrow(() -> new RuntimeException("Ticket no encontrado"));

                Orden orden = ticket.getOrden();
                Usuario usuario = usuarioRepository.findById(orden.getUsuario().getId())
                                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

                String fileName = String.format("ticket-orden-%d-reenvio.pdf", orden.getId());

                emailService.sendEmailWithAttachment(
                                usuario.getCorreoElectronico(),
                                "Reenvío Ticket de Compra - Orden #" + orden.getId(),
                                "Se reenvía el ticket solicitado.",
                                ticket.getArchivoPdf(),
                                fileName);
        }

        // Obtener ticket por orden ID
        @PreAuthorize("#ordenId == principal.id")
        public Ticket getTicketByOrdenId(Long ordenId) {
                return ticketRepository.findByOrdenId(ordenId).orElse(null);
        }

        // Crear cuerpo del email personalizado
        private String createEmailBody(Usuario usuario, Orden orden) {
                return String.format("""
                                Hola %s,

                                ¡Gracias por tu compra en ESCOM Hub!

                                Tu orden #%d ha sido procesada exitosamente.
                                Total: $%.2f
                                Fecha: %s

                                En el archivo adjunto encontrarás el ticket detallado de tu compra.

                                Si tienes alguna pregunta, no dudes en contactarnos.

                                ¡Saludos!
                                El equipo de ESCOM Hub
                                """,
                                usuario.getUsername(),
                                orden.getId(),
                                orden.getTotal(),
                                // Corregido: usa getFecha() en lugar de getFechaEmision()
                                orden.getFecha().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")));
        }
}