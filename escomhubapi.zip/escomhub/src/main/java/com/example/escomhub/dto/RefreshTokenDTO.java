package com.example.escomhub.dto;

public class RefreshTokenDTO {

    private String refreshToken;

    // Getters y Setters
    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }
}
