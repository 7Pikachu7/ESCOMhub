package com.example.escomhub.controller;

import com.example.escomhub.service.PagoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.access.prepost.PreAuthorize;
import com.stripe.exception.StripeException;

@RestController
@RequestMapping("/pagos")
public class PagoController {

    @Autowired
    private PagoService pagoService;

    @PreAuthorize("hasRole('USER')")
    @PostMapping("/create-payment-intent")
    public ResponseEntity<String> createPaymentIntent(@RequestBody Double amount) throws StripeException {
        String clientSecret = pagoService.createPaymentIntent(amount).getClientSecret();
        return ResponseEntity.ok(clientSecret);
    }
}
