package com.example.escomhub.service;

import com.example.escomhub.model.Categoria;
import com.example.escomhub.repository.CategoriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CategoriaService {

    @Autowired
    private CategoriaRepository categoriaRepository;

    // Obtener todas las categorías
    @PreAuthorize("permitAll()")
    public List<Categoria> getAllCategorias() {
        return categoriaRepository.findAll(); // Retorna todas las categorías desde la base de datos
    }

    // Obtener una categoría por ID
    @PreAuthorize("permitAll()")
    public Categoria getCategoriaById(Long id) {
        Optional<Categoria> categoria = categoriaRepository.findById(id);
        return categoria.orElse(null); // Retorna la categoría o null si no se encuentra
    }

    // Crear una nueva categoría
    @PreAuthorize("hasRole('VENDEDOR')")
    public Categoria createCategoria(Categoria categoria) {
        return categoriaRepository.save(categoria); // Guarda la nueva categoría
    }

    // Actualizar una categoría existente
    @PreAuthorize("hasRole('VENDEDOR')")
    public Categoria updateCategoria(Long id, Categoria categoria) {
        if (categoriaRepository.existsById(id)) {
            categoria.setId(id); // Establece el ID de la categoría para actualizar
            return categoriaRepository.save(categoria); // Guarda la categoría actualizada
        }
        return null; // Si no existe, devuelve null
    }

    // Eliminar una categoría por ID
    @PreAuthorize("hasRole('VENDEDOR')")
    public void deleteCategoria(Long id) {
        if (categoriaRepository.existsById(id)) {
            categoriaRepository.deleteById(id); // Elimina la categoría por ID
        }
    }
}
