package com.example.escomhub.security;

import com.example.escomhub.security.JwtTokenUtil;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
public class JwtAuthorizationFilter extends OncePerRequestFilter {

    private final JwtTokenUtil jwtTokenUtil;

    public JwtAuthorizationFilter(JwtTokenUtil jwtTokenUtil) {
        this.jwtTokenUtil = jwtTokenUtil;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        // Aquí puedes agregar la lógica para verificar los roles y permisos del usuario
        // basado en el JWT
        // Esto se puede hacer con un método adicional en el JwtTokenUtil para obtener
        // roles
        // Ejemplo: getRolesFromToken(token) y luego verificar si el rol tiene acceso al
        // recurso solicitado.

        filterChain.doFilter(request, response); // Permite continuar la cadena de filtros
    }
}
